
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fizz Buzz</title>
    <style>
        .center {
            text-align: center;
            border-bottom: 1px solid black;
            padding-right: 10%;
            padding-left: 10%;
        }
    </style>
</head>
<body>
    <div class="center">
        <h1> Fizz Buzz Math Game - PHP </h1>
        <p>Choosing PHP was more natural because it can be mixed with HTML for printing visual output. The logic behind the game is the same
            as in any other programming language, we are using a "for" loop to go thorugh the numbers and perform arithmetic operations to check for the division of a number. 
            Counting up from the number one to one hudred, printing “Fizz” when the number is divisible by three and “Buzz” when the number is divisible by five. 
            If a number is divisible by both three and five, then we print “Fizz Buzz” and if it's not devisible by 3 and 5 then we just print the number.</p>
        </div>

<br>
<div>
<?php
//A for loop that goes between 1 and 100
for ($i = 1; $i <= 100; $i++)
{

//If the number is divisible by both 3 and 5, then it is Fizz Buzz
  if ( $i%3 == 0 && $i%5 == 0 )
   {
     echo $i . " FizzBuzz"."<br>" ;
   }
   //If the number is divisible by 3, then it is Fizz
  else if ( $i%3 == 0 ) 
   {
     echo $i. " Fizz"."<br>";
   }
   //If the number is divisible by 5, then it is Buzz
     else if ( $i%5 == 0 ) 
   {
     echo $i. " Buzz"."<br>";
   }
   //If it isn't divisible by 3 or 5, just print out the number
     else
   {
     echo $i."<br>";
   }
 }
 ?>

</div>

</body>
</html>


